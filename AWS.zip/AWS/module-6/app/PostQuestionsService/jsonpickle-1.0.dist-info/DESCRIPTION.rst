jsonpickle converts complex Python objects to and from JSON.


